import { useLang } from "../../i18n";

export default function Marquee() {
  const { t } = useLang();
  const items = [...t.marquee, ...t.marquee];
  return (
    <div data-testid="editorial-marquee" className="relative mt-20 sm:mt-28 border-y border-[#D4AF37]/15 bg-[#0A1224]/60 py-6 sm:py-8 overflow-hidden">
      <div className="animate-marquee flex w-max items-center gap-10 sm:gap-16 whitespace-nowrap">
        {items.map((item, i) => (
          <span key={i} className="flex items-center gap-10 sm:gap-16">
            <span className={`font-serif-d text-2xl sm:text-4xl ${i % 2 === 0 ? "italic text-zinc-300" : "text-zinc-500"}`}>
              {item}
            </span>
            <span className="text-[#D4AF37] text-lg">◆</span>
          </span>
        ))}
      </div>
    </div>
  );
}
