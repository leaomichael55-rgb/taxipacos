import { ArrowUpRight } from "lucide-react";
import { Reveal, Eyebrow } from "./Reveal";
import { useLang } from "../../i18n";

export default function Services() {
  const { t } = useLang();
  return (
    <section id="servicos" data-testid="services-section" className="max-w-7xl mx-auto px-5 sm:px-8 py-16 sm:py-24">
      <Reveal>
        <Eyebrow>{t.services.eyebrow}</Eyebrow>
        <h2 className="mt-4 font-serif-d text-4xl sm:text-6xl tracking-tight text-zinc-100 font-medium">
          {t.services.title}{" "}
          <span className="italic text-gold-gradient">{t.services.titleItalic}</span>
        </h2>
      </Reveal>

      <div className="mt-12 sm:mt-16">
        {t.services.items.map((s, i) => (
          <Reveal key={s.title} delay={i * 0.06}>
            <div
              data-testid={`service-row-${i}`}
              className="group grid md:grid-cols-[70px_1fr_1.1fr_48px] items-start md:items-center gap-3 md:gap-8 border-t border-white/10 last:border-b py-7 sm:py-9 transition-colors duration-500 hover:bg-[#0D1830]/50 md:px-4"
            >
              <span className="font-mono-d text-sm text-[#D4AF37]/70">0{i + 1}</span>
              <h3 className="font-serif-d text-2xl sm:text-4xl text-zinc-100 font-medium transition-colors duration-500 group-hover:text-[#E6C665]">
                {s.title}
              </h3>
              <p className="text-sm sm:text-base text-zinc-400 leading-relaxed max-w-xl">{s.desc}</p>
              <ArrowUpRight
                className="hidden md:block text-zinc-600 transition-all duration-500 group-hover:text-[#D4AF37] group-hover:translate-x-1 group-hover:-translate-y-1"
                size={26}
              />
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
