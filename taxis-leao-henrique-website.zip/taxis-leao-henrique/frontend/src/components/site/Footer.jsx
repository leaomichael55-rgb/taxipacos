import { Phone, Mail } from "lucide-react";
import { useLang, CONTACT } from "../../i18n";

export default function Footer() {
  const { t } = useLang();
  return (
    <footer data-testid="footer" className="border-t border-white/5 bg-[#050910]">
      <div className="max-w-7xl mx-auto px-5 sm:px-8 py-12 sm:py-16 flex flex-col md:flex-row items-center justify-between gap-8">
        <div className="flex items-center gap-4">
          <img src="/assets/lion.png" alt="Táxis Leão & Henrique" className="h-14 w-14 rounded-full object-cover border border-[#D4AF37]/40" />
          <div>
            <p className="font-serif-d text-xl text-zinc-100">
              Leão <span className="text-[#D4AF37]">&</span> Henrique
            </p>
            <p className="font-mono-d text-[10px] tracking-[0.3em] text-zinc-500 uppercase">{t.footer.tag}</p>
          </div>
        </div>
        <div className="flex flex-col sm:flex-row items-center gap-4 sm:gap-8 text-sm text-zinc-400">
          <a data-testid="footer-phone" href={CONTACT.phone1Href} className="flex items-center gap-2 hover:text-[#E6C665] transition-colors">
            <Phone size={14} className="text-[#D4AF37]" /> {CONTACT.phone1}
          </a>
          <a data-testid="footer-email" href={`mailto:${CONTACT.email}`} className="flex items-center gap-2 hover:text-[#E6C665] transition-colors">
            <Mail size={14} className="text-[#D4AF37]" /> {CONTACT.email}
          </a>
        </div>
      </div>
      <div className="border-t border-white/5 py-5 text-center">
        <p className="font-mono-d text-[10px] tracking-[0.2em] text-zinc-600 uppercase">{t.footer.rights}</p>
      </div>
    </footer>
  );
}
