import { Star, Car, Award } from "lucide-react";
import { Reveal } from "./Reveal";
import { useLang } from "../../i18n";

const ICONS = { star: Star, car: Car, award: Award };

export default function Trust() {
  const { t } = useLang();
  return (
    <section data-testid="trust-stats" className="max-w-7xl mx-auto px-5 sm:px-8 py-20 sm:py-28">
      <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
        <Reveal>
          <p
            data-testid="trust-big-number"
            className="font-serif-d font-semibold text-gold-gradient leading-[0.9] text-[7rem] sm:text-[11rem] lg:text-[13rem] select-none"
          >
            50<span className="text-[0.45em] align-top">+</span>
          </p>
          <p className="mt-4 font-mono-d text-xs sm:text-sm uppercase tracking-[0.4em] text-zinc-400">
            {t.trust.bigLabel}
          </p>
        </Reveal>

        <div className="flex flex-col gap-5">
          {t.trust.pills.map((p, i) => {
            const Icon = ICONS[p.icon];
            return (
              <Reveal key={p.text} delay={0.1 + i * 0.12}>
                <div
                  data-testid={`trust-pill-${i}`}
                  className="group flex items-center gap-5 rounded-2xl border border-[#D4AF37]/25 bg-[#0D1830]/70 px-6 sm:px-8 py-5 sm:py-6 transition-all duration-500 hover:border-[#D4AF37]/60 hover:bg-[#0D1830]"
                >
                  {p.icon === "star" ? (
                    <span className="flex gap-1 shrink-0">
                      {[...Array(5)].map((_, s) => (
                        <Star key={s} size={18} className="fill-[#D4AF37] text-[#D4AF37]" />
                      ))}
                    </span>
                  ) : (
                    <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-[#D4AF37]/40 bg-[#D4AF37]/10 text-[#D4AF37] transition-transform duration-500 group-hover:scale-110">
                      <Icon size={20} />
                    </span>
                  )}
                  <p className="font-serif-d text-xl sm:text-2xl text-zinc-100">{p.text}</p>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
