import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Phone, Menu, X } from "lucide-react";
import { useLang, CONTACT } from "../../i18n";

export const scrollToId = (id) => {
  const el = document.getElementById(id);
  if (!el) return;
  if (window.__lenis) window.__lenis.scrollTo(el, { offset: -92 });
  else el.scrollIntoView({ behavior: "smooth" });
};

export default function Header() {
  const { lang, setLang, t } = useLang();
  const [open, setOpen] = useState(false);

  const links = [
    { id: "servicos", label: t.nav.services, testid: "nav-services-link" },
    { id: "frota", label: t.nav.fleet, testid: "nav-fleet-link" },
    { id: "empresa", label: t.nav.about, testid: "nav-about-link" },
    { id: "contactos", label: t.nav.contact, testid: "nav-contact-link" },
  ];

  return (
    <header className="fixed top-0 inset-x-0 z-50 bg-[#070D1A]/80 backdrop-blur-md border-b border-white/5">
      <div className="max-w-7xl mx-auto px-5 sm:px-8 h-[92px] flex items-center justify-between gap-4">
        <button
          data-testid="header-logo"
          onClick={() => scrollToId("hero")}
          className="flex items-center gap-3 sm:gap-4 shrink-0"
        >
          <img
            src="/assets/lion.png"
            alt="Leão & Henrique"
            className="h-14 w-14 sm:h-[68px] sm:w-[68px] rounded-full object-cover border-2 border-[#D4AF37]/50"
          />
          <span className="text-left leading-tight">
            <span className="block font-serif-d text-xl sm:text-3xl text-zinc-100">
              Leão <span className="text-[#D4AF37]">&</span> Henrique
            </span>
            <span className="block font-mono-d text-[9px] sm:text-[11px] tracking-[0.35em] text-[#D4AF37]/80 uppercase mt-0.5">
              Paços de Ferreira
            </span>
          </span>
        </button>

        <nav className="hidden lg:flex items-center gap-8">
          {links.map((l) => (
            <button
              key={l.id}
              data-testid={l.testid}
              onClick={() => scrollToId(l.id)}
              className="text-sm text-zinc-400 hover:text-[#E6C665] transition-colors duration-300 tracking-wide"
            >
              {l.label}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <div className="flex items-center rounded-full border border-white/10 overflow-hidden">
            {["pt", "en"].map((l) => (
              <button
                key={l}
                data-testid={`language-toggle-${l}`}
                onClick={() => setLang(l)}
                className={`px-3 py-1.5 font-mono-d text-[11px] uppercase tracking-widest transition-colors duration-300 ${
                  lang === l ? "bg-[#D4AF37] text-[#070D1A]" : "text-zinc-400 hover:text-zinc-200"
                }`}
              >
                {l}
              </button>
            ))}
          </div>
          <a
            data-testid="header-call-btn"
            href={CONTACT.phone1Href}
            className="hidden md:inline-flex items-center gap-2 rounded-full bg-[#D4AF37] hover:bg-[#E6C665] text-[#070D1A] text-sm font-semibold px-5 py-2.5 transition-colors duration-300"
          >
            <Phone size={15} strokeWidth={2.4} />
            {t.nav.call}
          </a>
          <button
            data-testid="mobile-menu-btn"
            onClick={() => setOpen(!open)}
            className="lg:hidden p-2 rounded-xl border border-white/10 text-zinc-300"
            aria-label="Menu"
          >
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <motion.nav
            data-testid="mobile-menu"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
            className="lg:hidden overflow-hidden border-t border-white/5 bg-[#070D1A]/95"
          >
            <div className="px-6 py-5 flex flex-col gap-4">
              {links.map((l) => (
                <button
                  key={l.id}
                  data-testid={`mobile-${l.testid}`}
                  onClick={() => {
                    setOpen(false);
                    scrollToId(l.id);
                  }}
                  className="text-left font-serif-d text-2xl text-zinc-200 hover:text-[#E6C665] transition-colors"
                >
                  {l.label}
                </button>
              ))}
              <a
                data-testid="mobile-call-btn"
                href={CONTACT.phone1Href}
                className="mt-2 inline-flex items-center justify-center gap-2 rounded-full bg-[#D4AF37] text-[#070D1A] font-semibold px-5 py-3"
              >
                <Phone size={16} />
                {t.nav.call} · 914 014 369
              </a>
            </div>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
}
