import { Phone, MessageCircle, Mail, MapPin, ExternalLink, Star } from "lucide-react";
import { Reveal, Eyebrow } from "./Reveal";
import { useLang, CONTACT } from "../../i18n";

export default function Contact() {
  const { t } = useLang();
  return (
    <section id="contactos" data-testid="contact-section" className="max-w-7xl mx-auto px-5 sm:px-8 py-20 sm:py-32">
      <Reveal>
        <Eyebrow>{t.contact.eyebrow}</Eyebrow>
        <h2 className="mt-4 font-serif-d text-5xl sm:text-7xl tracking-tight text-zinc-100 font-medium leading-[1.05]">
          {t.contact.title}{" "}
          <span className="italic text-gold-gradient">{t.contact.titleItalic}</span>
        </h2>
        <p className="mt-6 text-sm sm:text-lg text-zinc-400 leading-relaxed max-w-xl">{t.contact.desc}</p>
      </Reveal>

      <div className="mt-12 sm:mt-16 grid lg:grid-cols-2 gap-6 lg:gap-10">
        <div className="flex flex-col gap-6">
          <Reveal delay={0.05}>
            <a
              data-testid="contact-phone-1"
              href={CONTACT.phone1Href}
              className="group block rounded-3xl bg-[#D4AF37] hover:bg-[#E6C665] p-8 sm:p-10 transition-all duration-300 shadow-[0_0_45px_rgba(212,175,55,0.22)] hover:shadow-[0_0_60px_rgba(212,175,55,0.38)]"
            >
              <Phone size={36} strokeWidth={2.2} className="text-[#070D1A] transition-transform duration-300 group-hover:-rotate-12" />
              <p className="mt-7 font-mono-d text-[11px] uppercase tracking-[0.35em] text-[#070D1A]/70">
                {t.contact.callLabel}
              </p>
              <p className="mt-2 font-serif-d text-3xl sm:text-4xl font-semibold text-[#070D1A]">{CONTACT.phone1}</p>
            </a>
          </Reveal>
          <Reveal delay={0.12}>
            <a
              data-testid="contact-phone-2"
              href={CONTACT.phone2Href}
              className="group block rounded-3xl border border-white/10 hover:border-[#D4AF37]/50 bg-[#0D1830]/70 p-8 sm:p-10 transition-all duration-300"
            >
              <Phone size={36} strokeWidth={2.2} className="text-[#D4AF37] transition-transform duration-300 group-hover:-rotate-12" />
              <p className="mt-7 font-mono-d text-[11px] uppercase tracking-[0.35em] text-zinc-500">
                {t.contact.callLabel}
              </p>
              <p className="mt-2 font-serif-d text-3xl sm:text-4xl font-semibold text-zinc-100">{CONTACT.phone2}</p>
            </a>
          </Reveal>
          <Reveal delay={0.19}>
            <a
              data-testid="contact-whatsapp"
              href={CONTACT.whatsapp}
              target="_blank"
              rel="noopener noreferrer"
              className="group block rounded-3xl border border-emerald-500/40 hover:border-emerald-400/70 bg-emerald-950/30 p-8 sm:p-10 transition-all duration-300"
            >
              <MessageCircle size={36} className="text-emerald-400 transition-transform duration-300 group-hover:scale-110" />
              <p className="mt-7 font-mono-d text-[11px] uppercase tracking-[0.35em] text-emerald-500/80">
                {t.contact.waLabel}
              </p>
              <p className="mt-2 font-serif-d text-3xl sm:text-4xl font-semibold text-emerald-300">WhatsApp</p>
            </a>
          </Reveal>
        </div>

        <Reveal delay={0.15}>
          <div className="h-full rounded-3xl border border-white/10 bg-[#0D1830]/70 p-8 sm:p-10 flex flex-col gap-8">
            <div className="flex items-center gap-3 rounded-full border border-[#D4AF37]/30 bg-[#D4AF37]/10 px-5 py-2.5 w-fit">
              <Star size={15} className="fill-[#D4AF37] text-[#D4AF37]" />
              <span data-testid="contact-rating" className="font-mono-d text-xs tracking-[0.2em] text-[#E6C665] uppercase">
                {t.contact.rating}
              </span>
            </div>

            <div>
              <p className="font-mono-d text-[10px] uppercase tracking-[0.3em] text-zinc-500">{t.contact.emailLabel}</p>
              <a
                data-testid="contact-email"
                href={`mailto:${CONTACT.email}`}
                className="mt-2 flex items-center gap-3 text-lg sm:text-xl text-zinc-100 hover:text-[#E6C665] transition-colors break-all"
              >
                <Mail size={18} className="shrink-0 text-[#D4AF37]" />
                {CONTACT.email}
              </a>
            </div>

            <div className="h-px bg-white/10" />

            <div className="grid sm:grid-cols-2 gap-8">
              <div>
                <p className="font-mono-d text-[10px] uppercase tracking-[0.3em] text-zinc-500">{t.contact.standLabel}</p>
                <p data-testid="contact-stand" className="mt-2 flex items-start gap-3 text-base text-zinc-200 leading-relaxed">
                  <MapPin size={18} className="shrink-0 mt-1 text-[#D4AF37]" />
                  {t.contact.stand}
                </p>
              </div>
              <div>
                <p className="font-mono-d text-[10px] uppercase tracking-[0.3em] text-zinc-500">{t.contact.hqLabel}</p>
                <p data-testid="contact-hq" className="mt-2 flex items-start gap-3 text-base text-zinc-200 leading-relaxed">
                  <MapPin size={18} className="shrink-0 mt-1 text-[#D4AF37]" />
                  {t.contact.hq}
                </p>
              </div>
            </div>

            <a
              data-testid="contact-maps-link"
              href={CONTACT.mapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 text-sm font-semibold text-[#E6C665] hover:text-[#D4AF37] transition-colors"
            >
              {t.contact.maps}
              <ExternalLink size={15} />
            </a>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
