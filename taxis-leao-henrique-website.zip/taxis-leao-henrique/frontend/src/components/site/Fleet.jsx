import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Check } from "lucide-react";
import { Reveal, Eyebrow } from "./Reveal";
import { useLang } from "../../i18n";

const IMAGES = {
  sedan:
    "https://images.unsplash.com/photo-1610099610040-ab19f3a5ec35?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA1ODh8MHwxfHNlYXJjaHwxfHxtZXJjZWRlcyUyMGVsZWN0cmljJTIwY2FyJTIwbHV4dXJ5fGVufDB8fHx8MTc5MDc5ODUwNHww&ixlib=rb-4.1.0&q=85",
  electric:
    "https://images.unsplash.com/photo-1667141595930-fb72743b9cbe?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA1ODh8MHwxfHNlYXJjaHwzfHxtZXJjZWRlcyUyMGVsZWN0cmljJTIwY2FyJTIwbHV4dXJ5fGVufDB8fHx8MTc5MDc5ODUwNHww&ixlib=rb-4.1.0&q=85",
  vito:
    "https://images.unsplash.com/photo-1765461734605-34657fa04db2?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NTY2Njd8MHwxfHNlYXJjaHwxfHxtZXJjZWRlcyUyMHZpdG8lMjB2YW4lMjBibGFjayUyMGx1eHVyeXxlbnwwfHx8fDE3OTA3OTg1MDV8MA&ixlib=rb-4.1.0&q=85",
};

export default function Fleet() {
  const { t } = useLang();
  const [active, setActive] = useState("sedan");
  const current = t.fleet.tabs.find((x) => x.id === active);

  return (
    <section id="frota" data-testid="fleet-section" className="max-w-7xl mx-auto px-5 sm:px-8 py-16 sm:py-24">
      <Reveal>
        <Eyebrow>{t.fleet.eyebrow}</Eyebrow>
        <h2 className="mt-4 font-serif-d text-4xl sm:text-6xl tracking-tight text-zinc-100 font-medium max-w-3xl">
          {t.fleet.title}{" "}
          <span className="italic text-gold-gradient">{t.fleet.titleItalic}</span>
        </h2>
      </Reveal>

      <Reveal delay={0.15} className="mt-10 sm:mt-14">
        <div className="flex flex-wrap gap-3">
          {t.fleet.tabs.map((tab) => (
            <button
              key={tab.id}
              data-testid={`fleet-tab-${tab.id}`}
              onClick={() => setActive(tab.id)}
              className={`rounded-full px-5 sm:px-6 py-2.5 text-sm font-semibold transition-all duration-300 border ${
                active === tab.id
                  ? "bg-[#D4AF37] text-[#070D1A] border-[#D4AF37]"
                  : "border-white/15 text-zinc-400 hover:border-[#D4AF37]/50 hover:text-zinc-200"
              }`}
            >
              {tab.name}
            </button>
          ))}
        </div>

        <div className="mt-8 grid lg:grid-cols-2 gap-8 lg:gap-14 items-center">
          <div className="spotlight-frame relative rounded-2xl sm:rounded-3xl overflow-hidden border border-white/10 aspect-[4/3] bg-[#0D1830]">
            <AnimatePresence mode="wait">
              <motion.img
                key={active}
                data-testid="fleet-image"
                src={IMAGES[active]}
                alt={current.name}
                initial={{ opacity: 0, scale: 1.06 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
                className="absolute inset-0 w-full h-full object-cover"
              />
            </AnimatePresence>
            <div className="absolute inset-0 bg-gradient-to-t from-[#070D1A]/70 via-transparent to-transparent z-[1]" />
            {current.badge && (
              <span
                data-testid="fleet-badge"
                className={`absolute top-4 left-4 z-10 rounded-full px-4 py-1.5 font-mono-d text-[11px] tracking-[0.2em] font-medium ${
                  active === "electric"
                    ? "bg-emerald-500/90 text-[#070D1A]"
                    : "bg-[#D4AF37] text-[#070D1A]"
                }`}
              >
                {current.badge}
              </span>
            )}
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={active + "-txt"}
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.55 }}
            >
              <h3 data-testid="fleet-name" className="font-serif-d text-3xl sm:text-5xl text-zinc-100 font-medium">
                {current.name}
              </h3>
              <p className="mt-4 text-sm sm:text-lg text-zinc-400 leading-relaxed max-w-lg">{current.desc}</p>
              <ul className="mt-7 grid grid-cols-1 sm:grid-cols-2 gap-3">
                {current.features.map((f) => (
                  <li key={f} className="flex items-center gap-3 text-sm text-zinc-300">
                    <span className="flex h-5 w-5 items-center justify-center rounded-full border border-[#D4AF37]/40">
                      <Check size={11} className="text-[#D4AF37]" />
                    </span>
                    {f}
                  </li>
                ))}
              </ul>
            </motion.div>
          </AnimatePresence>
        </div>
      </Reveal>
    </section>
  );
}
