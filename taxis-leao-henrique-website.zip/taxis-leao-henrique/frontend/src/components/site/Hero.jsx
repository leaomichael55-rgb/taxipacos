import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { Phone, MessageCircle, ChevronDown } from "lucide-react";
import { useLang, CONTACT } from "../../i18n";

const MaskedLine = ({ children, delay, className = "" }) => (
  <span className="block overflow-hidden pb-1">
    <motion.span
      className={`block ${className}`}
      initial={{ y: "115%" }}
      animate={{ y: 0 }}
      transition={{ duration: 1.1, delay, ease: [0.16, 1, 0.3, 1] }}
    >
      {children}
    </motion.span>
  </span>
);

export default function Hero() {
  const { t } = useLang();
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const yBg = useTransform(scrollYProgress, [0, 1], [0, 140]);
  const yPhoto = useTransform(scrollYProgress, [0, 1], [0, -70]);
  const opacity = useTransform(scrollYProgress, [0, 0.75], [1, 0]);

  return (
    <section id="hero" ref={ref} data-testid="hero-section" className="relative overflow-hidden pt-32 sm:pt-36">
      <motion.div style={{ y: yBg, opacity }} className="absolute inset-0 pointer-events-none">
        <div className="absolute top-[-20%] left-1/2 -translate-x-1/2 w-[900px] h-[700px] rounded-full bg-[#D4AF37]/[0.07] blur-[140px]" />
        <div className="absolute bottom-[-30%] right-[-10%] w-[600px] h-[500px] rounded-full bg-[#16304F]/40 blur-[120px]" />
      </motion.div>

      <div className="relative max-w-7xl mx-auto px-5 sm:px-8 text-center">
        <motion.p
          data-testid="hero-eyebrow"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.15 }}
          className="font-mono-d text-[10px] sm:text-xs uppercase tracking-[0.3em] sm:tracking-[0.4em] text-[#D4AF37]/90"
        >
          {t.hero.eyebrow}
        </motion.p>

        <motion.div
          initial={{ opacity: 0, scale: 0.82, y: 24 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 1.3, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
          className="mt-8 sm:mt-10 flex justify-center"
        >
          <img
            data-testid="hero-logo"
            src="/assets/lion.png"
            alt="Logotipo Táxis Leão & Henrique — leão dourado"
            className="gold-glow h-44 sm:h-60 lg:h-72 w-auto rounded-[2rem]"
          />
        </motion.div>

        <h1 className="mt-8 sm:mt-10 font-serif-d font-semibold tracking-tight leading-[1.02] text-5xl sm:text-7xl lg:text-8xl">
          <MaskedLine delay={0.55} className="text-zinc-100">
            {t.hero.line1}
          </MaskedLine>
          <MaskedLine delay={0.7} className="italic text-gold-gradient pb-2">
            {t.hero.line2}
          </MaskedLine>
        </h1>

        <motion.p
          data-testid="hero-sub"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 1.0 }}
          className="mt-6 sm:mt-8 max-w-2xl mx-auto text-sm sm:text-lg text-zinc-400 leading-relaxed"
        >
          {t.hero.sub}
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 1.15 }}
          className="mt-8 sm:mt-10 flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <a
            data-testid="hero-call-btn"
            href={CONTACT.phone1Href}
            className="group inline-flex items-center gap-3 rounded-full bg-[#D4AF37] hover:bg-[#E6C665] text-[#070D1A] font-bold text-base sm:text-lg px-8 py-4 transition-all duration-300 shadow-[0_0_40px_rgba(212,175,55,0.25)] hover:shadow-[0_0_55px_rgba(212,175,55,0.4)]"
          >
            <Phone size={19} strokeWidth={2.4} className="transition-transform duration-300 group-hover:-rotate-12" />
            {t.hero.cta1}
          </a>
          <a
            data-testid="hero-whatsapp-btn"
            href={CONTACT.whatsapp}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-3 rounded-full border border-emerald-500/60 text-emerald-400 hover:bg-emerald-500/10 font-semibold text-base sm:text-lg px-8 py-4 transition-colors duration-300"
          >
            <MessageCircle size={19} />
            {t.hero.cta2}
          </a>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.6, duration: 1 }}
          className="mt-10 flex flex-col items-center gap-2 text-zinc-500"
        >
          <span className="font-mono-d text-[10px] uppercase tracking-[0.3em]">{t.hero.scroll}</span>
          <motion.span animate={{ y: [0, 7, 0] }} transition={{ repeat: Infinity, duration: 1.8, ease: "easeInOut" }}>
            <ChevronDown size={18} className="text-[#D4AF37]" />
          </motion.span>
        </motion.div>

        <motion.div
          style={{ y: yPhoto }}
          initial={{ opacity: 0, y: 60 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2, delay: 1.3, ease: [0.16, 1, 0.3, 1] }}
          className="mt-12 sm:mt-16"
        >
          <div className="relative left-1/2 -translate-x-1/2 w-screen max-w-[1500px] px-3 sm:px-6">
            <div className="spotlight-frame rounded-2xl sm:rounded-3xl border border-[#D4AF37]/25 overflow-hidden shadow-[0_30px_80px_rgba(0,0,0,0.6)]">
              <img
                data-testid="hero-fleet-photo"
                src="/assets/fleet.jpg"
                alt="Frota Mercedes-Benz dos Táxis Leão & Henrique em Lamoso, Paços de Ferreira"
                className="w-full h-auto"
              />
            </div>
          </div>
          <div className="mt-5 flex items-center justify-center gap-3">
            <img src="/assets/lion.png" alt="" className="h-6 w-6 rounded-full object-cover" />
            <span data-testid="hero-photo-badge" className="font-mono-d text-[10px] sm:text-xs tracking-[0.3em] text-[#E6C665] uppercase">
              {t.hero.photoBadge}
            </span>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
