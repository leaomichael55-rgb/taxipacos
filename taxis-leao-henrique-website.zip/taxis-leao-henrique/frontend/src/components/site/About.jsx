import { CreditCard, Smartphone, Wallet } from "lucide-react";
import { Reveal, Eyebrow } from "./Reveal";
import { useLang } from "../../i18n";

const PAY_ICONS = { card: CreditCard, phone: Smartphone, wallet: Wallet };

export default function About() {
  const { t } = useLang();
  return (
    <section id="empresa" data-testid="about-section" className="border-y border-white/5 bg-[#0A1224]/50">
      <div className="max-w-7xl mx-auto px-5 sm:px-8 py-20 sm:py-28">
        <div className="grid lg:grid-cols-2 gap-14 lg:gap-20 items-center">
          <Reveal>
            <Eyebrow>{t.about.storyEyebrow}</Eyebrow>
            <h2 className="mt-4 font-serif-d text-4xl sm:text-6xl tracking-tight text-zinc-100 font-medium leading-[1.08]">
              {t.about.storyTitle}
            </h2>
            <p className="mt-7 text-sm sm:text-lg text-zinc-400 leading-relaxed">{t.about.storyP1}</p>
            <p className="mt-5 text-sm sm:text-lg text-zinc-400 leading-relaxed">{t.about.storyP2}</p>
          </Reveal>
          <Reveal delay={0.15}>
            <div className="spotlight-frame relative rounded-3xl border border-[#D4AF37]/30 bg-[#0D1830]/80 p-10 sm:p-14 flex justify-center overflow-hidden">
              <img
                data-testid="about-lion"
                src="/assets/lion.png"
                alt="Leão dourado — símbolo dos Táxis Leão & Henrique"
                className="gold-glow relative z-[2] w-full max-w-xs sm:max-w-sm rounded-2xl"
              />
            </div>
          </Reveal>
        </div>

        <div className="mt-20 sm:mt-28 text-center">
          <Reveal>
            <Eyebrow>{t.about.payEyebrow}</Eyebrow>
            <h3 className="mt-4 font-serif-d text-3xl sm:text-5xl tracking-tight text-zinc-100 font-medium">
              {t.about.payTitle}
            </h3>
            <p className="mt-3 text-sm sm:text-base text-zinc-400">{t.about.paySub}</p>
          </Reveal>
          <div className="mt-10 grid sm:grid-cols-3 gap-5 text-left">
            {t.about.payments.map((p, i) => {
              const Icon = PAY_ICONS[p.icon];
              return (
                <Reveal key={p.title} delay={i * 0.12}>
                  <div
                    data-testid={`pay-card-${p.icon}`}
                    className="group h-full rounded-2xl border border-[#D4AF37]/20 bg-[#0D1830]/70 p-7 sm:p-8 transition-all duration-500 hover:border-[#D4AF37]/50 hover:-translate-y-1"
                  >
                    <span className="flex h-14 w-14 items-center justify-center rounded-xl border border-[#D4AF37]/40 bg-[#D4AF37]/10 text-[#D4AF37] transition-transform duration-500 group-hover:scale-110">
                      <Icon size={24} />
                    </span>
                    <h4 className="mt-5 font-serif-d text-2xl text-zinc-100">{p.title}</h4>
                    <p className="mt-2 text-sm text-zinc-400 leading-relaxed">{p.desc}</p>
                  </div>
                </Reveal>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
