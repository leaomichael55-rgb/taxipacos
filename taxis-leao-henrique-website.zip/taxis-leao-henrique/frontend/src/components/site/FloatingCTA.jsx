import { motion } from "framer-motion";
import { Phone, MessageCircle } from "lucide-react";
import { CONTACT } from "../../i18n";

export default function FloatingCTA() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 2, duration: 0.8 }}
      className="fixed bottom-5 right-5 z-50 flex flex-col gap-3"
    >
      <a
        data-testid="floating-whatsapp-btn"
        href={CONTACT.whatsapp}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="WhatsApp"
        className="flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500 text-white shadow-[0_8px_30px_rgba(16,185,129,0.45)] transition-transform duration-300 hover:scale-110"
      >
        <MessageCircle size={24} />
      </a>
      <a
        data-testid="floating-call-btn"
        href={CONTACT.phone1Href}
        aria-label="Ligar"
        className="flex h-14 w-14 items-center justify-center rounded-full bg-[#D4AF37] text-[#070D1A] shadow-[0_8px_30px_rgba(212,175,55,0.45)] transition-transform duration-300 hover:scale-110"
      >
        <Phone size={22} strokeWidth={2.4} />
      </a>
    </motion.div>
  );
}
