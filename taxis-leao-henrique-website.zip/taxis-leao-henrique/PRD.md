# PRD — Táxis Leão & Henrique (taxipacos.pt)

## Problem statement (original)
Website para empresa de táxis de Paços de Ferreira (sede em Lamoso), 50 anos no setor. Clientes: empresas, seguradoras, transporte escolar, airport pickups. Frota exclusivamente Mercedes-Benz (4 viaturas; uma 100% elétrica; uma Vito até 8 passageiros). Logotipo do leão (dourado sobre azul navy) e fotografia real da frota fornecidos pelo cliente. Objetivo: gerar chamadas telefónicas, WhatsApp e email.

## Decisões do cliente (vinculativas)
- Marca: **Táxis Leão & Henrique** — título "Leão & Henrique, Serviço de Táxis." com logotipo grande em destaque no hero.
- Idiomas: PT (default) + EN.
- Estilo: classy/premium, navy + dourado (cores do logotipo).
- NÃO mencionar casamentos nem serviço 24h/madrugada/discotecas. Foco: cliente empresarial (airport pickups) e serviço ocasional diurno (Porto e todo o país).
- Motoristas treinados com inglês fluente (clientes estrangeiros/turistas).
- Pagamentos: MB Way, Apple Pay, cartão débito/crédito, terminal a bordo.
- 5.0★ avaliação Google em destaque; formato de stats com números grandes aprovado pelo cliente.
- Título da frota: "Frota de táxis exclusivamente Mercedes-Benz" (não "quatro").
- Foto da frota mostrada na íntegra (sem cortes).
- Domínio do cliente: **taxipacos.pt** (ligar no Deploy → domínio personalizado).

## Contactos
- Tel 1: +351 914 014 369 (principal / CTA "Chamar Táxi")
- Tel 2 (telemóvel do proprietário): +351 918 079 004
- WhatsApp: wa.me/351918079004 (mensagem pré-preenchida)
- Email: coelhoeirmalda@gmail.com
- Praça de Táxis: R. Ferrara Plaza, 4590-073 Carvalhosa
- Sede: Lamoso, Paços de Ferreira

## Arquitetura
- Frontend-only (React + Tailwind + framer-motion + lenis). Sem backend necessário (contactos via tel:/mailto:/wa.me).
- i18n próprio em `/app/frontend/src/i18n.jsx` (PT/EN + constantes de contacto).
- Componentes em `/app/frontend/src/components/site/`: Header, Hero (logo grande + masked reveal + parallax + foto frota), Marquee, Trust (stats 50+ / 4 / 5.0★ / 8), Services (5 serviços), Fleet (tabs Sedan/Elétrico/Vito), About (equipa EN + pagamentos), Contact, Footer, FloatingCTA.
- Assets do cliente em `/app/frontend/public/assets/`: lion.png (logotipo), lockup.png, favicon.png, fleet.jpg (foto real da frota, 849x346).
- Imagens das tabs da frota (Sedan/Elétrico/Vito) são TEMPORÁRIAS (Unsplash) — substituir por fotos reais quando o cliente enviar.

## Implementado (30 Set 2026)
- Site completo PT/EN, responsivo (375/768/1366 verificado), hero com logotipo grande, reveal animado, parallax, foto da frota na íntegra, serviços, frota interativa, contactos com ambos os números, WhatsApp flutuante, favicon do leão.
- Formatos aprovados pelo cliente: cabeçalho com leão grande + marca em letras grandes; "50+" gigante dourado com cartões de destaque (5.0 Google / Frota 100% Mercedes-Benz / Lamoso); história "Meio século ao volante" com leão emoldurado; cartões de pagamento (Cartão/Apple Pay/MB Way); cartões grandes de contacto; marquee de rodapé a listar serviços (aeroporto, empresas, seguradoras, escolar, ocasional, grupos).
- "5.0★ Google" removido do topo (hero eyebrow) a pedido — permanece na secção 50+ e nos contactos.
- Fix: snippet posthog restaurado (erro "Unexpected token )" resolvido), foto da frota sem corte, título da frota "exclusivamente Mercedes-Benz".

## Backlog
- P0: Substituir imagens temporárias das tabs da frota por fotos reais das viaturas.
- P1: Ligar domínio taxipacos.pt no Deploy.
- P1: Fotografia adicional do interior/motoristas para a secção "A Empresa".
- P2: Link para avaliações Google / botão "Avalie-nos no Google".
- P2: SEO local (schema.org LocalBusiness/TaxiService).

## Verificação
- Preview testado: hero, EN toggle, tabs da frota, ambos os telefones, WhatsApp, email, Google Maps link — tudo funcional. Sem erros de runtime.
